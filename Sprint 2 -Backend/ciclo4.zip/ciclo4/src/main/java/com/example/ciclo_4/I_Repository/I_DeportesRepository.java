package com.example.ciclo_4.I_Repository;
import com.example.ciclo_4.Collection.Deportes;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface I_DeportesRepository extends MongoRepository<Deportes, String> {
}
